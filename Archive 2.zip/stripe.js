<script src="https://js.stripe.com/v3/"></script>
var stripe = Stripe('pk_test_jxUg204A6OkUg6qyhW3YTWCu00RfKazuKW');
